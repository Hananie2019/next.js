// import express into our project
const express = require('express')

/* Our server needs to:
    Listen for client requests
    and respond with data */

// create a new express application
const app = express()

// define server port
const port = 3000

// localhost:3000, localhost:3000/
// create our first route
app.get('/', (req, res) => {
  res.send("Hello World! We're live on our first server!")
})

// tell express to listen to traffic on our port
app.listen(port, () => {
  console.log(`Our app is listening on port ${port}`)
})

//localhost:3000/test
app.get('/test', (req, res) => {
  res.send('<html> <body> <h1> Testing Sending HTML </h1> </body> </html>')
})

// 4 HTTP Methods: GET, POST, PUT, DELETE
